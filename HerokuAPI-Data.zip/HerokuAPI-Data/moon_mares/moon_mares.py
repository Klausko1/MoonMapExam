import json

with open('mares.json', 'r') as f:
    mares_data = json.load(f)

with open('insert_moon_mares.sql', 'w') as sql_file:
    for feature in mares_data['features']:
        name = feature['properties']['name']
        coordinates = feature['geometry']['coordinates']

        sql_file.write(f"INSERT INTO moon_mares (name, coordinates) VALUES ('{name}', ARRAY{coordinates});\n")
