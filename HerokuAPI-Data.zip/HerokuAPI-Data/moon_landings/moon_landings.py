import json


json_file_path = 'C:/Users/Herman/Documents/HerokuAPI-Data/moon_landings/moon_landings.json'

with open(json_file_path) as f:
    data = json.load(f)

sql_statements = []

for landing in data:
    columns = ', '.join(landing.keys())
    values = ', '.join([f"'{value}'" for value in landing.values()])
    sql = f"INSERT INTO moon_landings ({columns}) VALUES ({values});"
    sql_statements.append(sql)

with open('insert_moon_landings.sql', 'w') as f:
    for statement in sql_statements:
        f.write(statement + '\n')

print("SQL script generated successfully")
