import json

with open('near_far_side.json', 'r') as f:
    sides_data = json.load(f)

with open('insert_moon_sides.sql', 'w') as sql_file:
    for feature in sides_data['features']:
        name = feature['properties']['name']
        coordinates = feature['geometry']['coordinates']

        sql_file.write(f"INSERT INTO moon_sides (name, coordinates) VALUES ('{name}', ARRAY{coordinates});\n")
