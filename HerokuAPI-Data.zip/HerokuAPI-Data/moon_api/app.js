const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 3000;

const pool = new Pool({
  connectionString: 'postgres://sxrpvntssjnnhn:06d68b4955188937fb3e92a282987e24720c0e8e8a4b67e60d7387827c756d45@ec2-34-241-82-91.eu-west-1.compute.amazonaws.com:5432/db4frpbgetpn55',
  ssl: {
    rejectUnauthorized: false
  }
});

app.use(cors());

// endpoints to retrieve data

// Endpoint, moon landings data
app.get('/moon-landings', async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM moon_landings');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching data from database', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Endpoint, moon craters data
app.get('/moon-craters', async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM moon_craters');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching data from database', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Endpoint, moon mare data
app.get('/moon-mares', async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM moon_mares');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching data from database', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Endpoint, moon sides data
app.get('/moon-sides', async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM moon_sides');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching data from database', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

app.get('/', (req, res) => {
  res.send('api working');
});
