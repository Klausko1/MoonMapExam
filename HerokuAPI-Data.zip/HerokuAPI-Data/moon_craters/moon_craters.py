import json

json_file_path = 'C:/Users/Herman/Documents/HerokuAPI-Data/moon_craters/craters.json'
with open(json_file_path) as f:
    craters_data = json.load(f)

output_sql_file_path = 'insert_moon_craters.sql'

with open(output_sql_file_path, 'w') as sql_file:
    for feature in craters_data['features']:
        properties = feature['properties']
        name = properties['name']
        age = properties['Age']
        wiki = properties['Wiki']
        num_points = properties['numPoints']
        radius = properties['radius']
        longitude, latitude = feature['geometry']['coordinates']
        sql_query = f"INSERT INTO moon_craters (name, age, wiki, num_points, radius, longitude, latitude) VALUES ('{name}', '{age}', '{wiki}', {num_points}, {radius}, {longitude}, {latitude});\n"
        sql_file.write(sql_query)

print("SQL script generated successfully.")
