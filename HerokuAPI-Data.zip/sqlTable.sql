CREATE TABLE moon_craters (
    name VARCHAR(100),
    age VARCHAR(50),
    wiki VARCHAR(200),
    num_points INTEGER,
    radius FLOAT,
    longitude FLOAT,
    latitude FLOAT
);


CREATE TABLE moon_mares (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    coordinates NUMERIC[][]
);

CREATE TABLE moon_sides (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    description VARCHAR,
    wiki VARCHAR,
    coordinates NUMERIC[][]
);


CREATE TABLE moon_landings (
    id SERIAL PRIMARY KEY,
    lat DOUBLE PRECISION,
    lng DOUBLE PRECISION,
    label VARCHAR,
    program VARCHAR,
    agency VARCHAR,
    date DATE,
    description VARCHAR,
    image VARCHAR,
    url VARCHAR
);